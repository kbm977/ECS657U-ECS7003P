﻿using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class BasicRigidBodyPush : MonoBehaviour
{
	public LayerMask pushLayers;
	public bool canPush;
	[Range(0.5f, 5f)] public float strength = 1.1f;

	[SerializeField] TextMeshProUGUI txtStars;

	int stars = 0;

	private void Start()
	{
		SetStar();

    }

	void SetStar()
	{
		txtStars.text = stars.ToString();
	}

    private void OnControllerColliderHit(ControllerColliderHit hit)
	{
		if (canPush) PushRigidBodies(hit);

		if (hit.gameObject.name.StartsWith("Trap"))
		{
			SceneManager.LoadScene(0);
		}

        if (hit.gameObject.name.StartsWith("FX Star"))
        {
			stars++;
			SetStar();

            Destroy(hit.gameObject);
        }
        

    }

	

	private void PushRigidBodies(ControllerColliderHit hit)
	{
		
		// make sure we hit a non kinematic rigidbody
		Rigidbody body = hit.collider.attachedRigidbody;
		if (body == null || body.isKinematic) return;

		// make sure we only push desired layer(s)
		var bodyLayerMask = 1 << body.gameObject.layer;
		if ((bodyLayerMask & pushLayers.value) == 0) return;

		// We dont want to push objects below us
		if (hit.moveDirection.y < -0.3f) return;

		// Calculate push direction from move direction, horizontal motion only
		Vector3 pushDir = new Vector3(hit.moveDirection.x, 0.0f, hit.moveDirection.z);

		// Apply the push and take strength into account
		body.AddForce(pushDir * strength, ForceMode.Impulse);
	}

  
}